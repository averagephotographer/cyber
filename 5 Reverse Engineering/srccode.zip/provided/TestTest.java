class TestTest
{
    public static void main(String [] args)
    {
	Test t = new Test();
	t.method1();
	// Try uncommenting the command below and discuss why it doesn't
	// work (and shouldn't work).
	//t.method2();
	t.method3(8);
    }
}
