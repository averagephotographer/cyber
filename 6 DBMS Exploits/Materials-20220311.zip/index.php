<?php require_once("db.php"); ?>
<html>
	<head>
		<title>I AM DEMOGORGON.  FEAR ME!</title>
	</head>
	
	<body>
		I AM DEMOGORGON.  FEAR ME!<p/>

<?php
	if ($_POST && isset($_POST["team"]) && $_POST["team"] != "")
	{
		$name = $_POST["team"];

		db_connect();
		$q = db_query("SELECT `name`,`score` FROM teams WHERE `name`='$name'");
		while ($r = db_fetch($q, "num"))
		{
			$name = $r[0];
			$score = $r[1];
			echo "\t\t$name, your score is $score!<br/>\n";
		}
	}
	else
	{
		echo <<< END
		<form method="post" action="">
			Team name: <input type="text" name="team"/>
			<input type="submit"/>
		</form>

END;
	}
?>
	</body>
</html>
