CREATE DATABASE cyber;
CREATE USER 'cyber'@'localhost' IDENTIFIED BY 'cyber';
GRANT ALL PRIVILEGES ON cyber.* TO 'cyber'@'localhost';
